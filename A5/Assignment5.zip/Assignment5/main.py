from flask import Flask, render_template, jsonify, request
import sqlite3
from sqlite3 import Error
import json
from urllib.request import urlopen


app=Flask(__name__)
TEMPLATES_AUTO_RELOAD = True

#creates connection with sqlite

def create_connection(db_file):
    try:
        conn = sqlite3.connect(db_file, check_same_thread=False)
        print(sqlite3.version)
        return conn
    except Error:
        print(Error)

    return None

#using the databse we configured with triggers/etc.
database = "A5_Final.db"
conn = create_connection(database)


#route for new flower sighting, grabs data from text fields and 
#executes a SQL statement with those values
@app.route('/insertNewSighting')
def insertSighting():

    name = request.args.get('name')
    person = request.args.get('person')
    location = request.args.get('location')
    date= request.args.get('date')

    cur = conn.cursor()
    sql = ('INSERT INTO SIGHTINGS '
            'VALUES (?,?,?,?)')
    cur.execute(sql, (name, person, location, date))
    conn.commit()

    return jsonify(result = "New Sighting " + name + " has been added")

#route for updating flower sighting, grabs data from text fields and 
#executes a SQL statement with those values
@app.route('/updateFlowerInfo')
def updateFlower():

    name = request.args.get('name')
    genus = request.args.get('genus')
    species = request.args.get('species')

    cur = conn.cursor()

    sql = ('UPDATE FLOWERS '
            'SET SPECIES = ?, GENUS = ? '
                'WHERE COMNAME = ?'
            )
    cur.execute(sql, (genus, species, name))
    conn.commit()

    return jsonify(result = name + " has been updated")

#home route for application that grabs all common 
#names from flower database and displays them 
#to home page
@app.route("/")
def getCommonNames():

    with conn:
        print("Getting all common names from Flowers Database")

    cur = conn.cursor()
    cur.execute("SELECT COMNAME FROM FLOWERS")
    conn.commit()

    data=cur.fetchall()
    for i in range(0, len(data)):
        data[i] = ''.join(data[i])
        data[i]= data[i].replace("('","")
        data[i] = data[i].replace("',)","")

    return render_template('home.html', data=data)

#route for scientific name that grabs name from text
#and executes a SQL statement with that value
@app.route("/scientificName")
def getScientificName():
        name = request.args.get('name')
        cur = conn.cursor()
        cur.execute("SELECT SPECIES, GENUS FROM FLOWERS WHERE COMNAME = ?", (name, ))
        conn.commit()
        data=cur.fetchall()

        with conn:
            print(data)

        return jsonify(result = data)

#route for grabbing 10 most recent sightings, gets flower name
#and executes a SQL statement based on that value
@app.route('/get10Sightings')
def getSightings():
    flowerName = request.args.get('name')

    with conn:
        print("this is the data" + flowerName)

    sql = ('SELECT PERSON, LOCATION, SIGHTED '
           'FROM SIGHTINGS '
           'WHERE NAME = ? '
           'ORDER BY SIGHTED DESC '
           'LIMIT 10; ')

    cur = conn.cursor()
    cur.execute(sql, (flowerName, ))

    r = [dict((cur.description[i][0], value) \
               for i, value in enumerate(row)) for row in cur.fetchall()]

    return jsonify(result=r)

#route for grabbing the amount of sightings requested 
#from previous route
@app.route('/getCountSightings')
def getNumSightings():
    name = request.args.get('name')

    with conn:
        print("this is the data" + name)

    sql = ('SELECT Count(*) '
       'FROM SIGHTINGS AS S, FLOWERS as F '
       'WHERE F.COMNAME = S.NAME  '
       'AND S.NAME = ?')

    cur = conn.cursor()
    cur.execute(sql, (name, ))
    conn.commit()
    query=cur.fetchall()

    query = ''.join(str(query[0]))
    query = query.replace('(',"")
    query = query.replace('',"")

    return jsonify(result=query)


if __name__ == "__main__":
    app.run()
