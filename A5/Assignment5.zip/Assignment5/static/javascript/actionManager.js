var flowerSelected = false;

$(document).ready(function() {
if(!flowerSelected) {
  $("#right-container").children().hide();
  $("#right-container").children().children().hide();
}

//Handles submit button
  $("#insertNewSighting").submit(function(e) {

      e.preventDefault();
      $('.error').hide();
      //grabs value from name input
  	  var person = $("input#nameInput").val();
  		if (person == "") {
        $("small#person-error").show();
        $("input#nameInput").focus();
        return false;
      }
      //grabs value from location input
  		var location = $("input#location-input").val();
  		if (location == "") {
        $("small#location-error").show();
        $("input#location-input").focus();
        return false;
      }
      //grabs value from date input
  		var date = $("input#dateInput").val();
  		if (date == "") {
        $("small#date-error").show();
        $("input#dateInput").focus();
        return false;
      }

      $("#insert-panel").hide();
      var name = $('h2').text();

      //sends ajax request with collected name, location, and date
      $.ajax({
          type: 'GET',
          url: "/insertNewSighting",
          data: {name: name, person: person, location: location, date: date},
          dataType: 'json',
          contentType: 'application/json; charset=utf-8',
          success: function(data) {
            console.log(data.result);
          }
      });
  });


//handles the edit genus/species form
  $("#editForm").submit( function(e) {

      e.preventDefault();
      //grabs common name from text
      var comname = $('h2').text();

      var array = String($('h4').text());
      console.log(array);
      array = array.split(' ');
      console.log(array[0] + array[1]);

      //grabs input from genus textbox
      var genus = $("input#genusInput").val();
      if (genus == "") {
        genus = array[0];
      }
      //grabs input from species textbox
      var species = $("input#speciesInput").val();
      if (species == "") {
        species = array[1];
      }

      //sends ajax request with collected common name, genus, and species
      $.ajax({
          type: 'GET',
          url: "/updateFlowerInfo",
          data: {name: comname, genus: genus, species: species},
          dataType: 'json',
          contentType: 'application/json; charset=utf-8',
          success: function(data) {
            console.log(data.result);
            $('h4').text('Scientific name: '+ genus + ' ' + species);
          }
      });
  });



//when a flower is clicked, gets last 10 sightings
$( ".clickable" ).click(function() {
    //removes previous flowers' sightings
    $(".temp-row").remove();

    //grabs common name
    var comname = $(this).text();
    var count = 1;

    //performs a get request to grab last 10 sightings of a flower
    $.ajax({
        type: 'GET',
        url: "/get10Sightings",
        data: {name: comname},
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        success: function(data) {
          $(".flowerTitle").text(comname);
          $.each(data, function(index, array){
              $.each(array, function(j, tuple){
                var row = $("<tr>?</tr>");
                $("#sighting-table-body").append(row);

                row.attr('id', j);
                row.attr('class', 'temp-row');

                var col = $("<td>" + tuple['PERSON'] + "</td>"
                +  "<td>" + tuple['LOCATION'] + "</td>"
                + "<td>" + tuple['SIGHTED'] + "</td>");

                $("#" + j).append(col);
              });
          });

          if(!flowerSelected)
          {
            $("#right-container").children().show();
            $("#right-container").children().children().show();
            $("#insert-panel").hide();
            flowerSelected = true;
          }
        }
      });
      //gets scientific name of flower using the common name
      $.ajax({
          type: 'GET',
          url: "/scientificName",
          data: {name: comname},
          dataType: 'json',
          contentType: 'application/json; charset=utf-8',
          success: function(data) {
            console.log(data.result[0][1]);
            $('h4#scientificName').text("Scientific Name: " + data.result[0][1] + ' ' + data.result[0][0]);
          }
        });
});

});
